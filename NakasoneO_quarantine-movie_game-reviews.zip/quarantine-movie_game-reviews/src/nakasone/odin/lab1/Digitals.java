package nakasone.odin.lab1;

public class Digitals {
	
	private int id;
	private String title;
	private float rating;
	private String review;
	
	public Digitals() {
		
	}
	
	public Digitals(int id, String title, float rating, String review) {
		setId(id);
		setTitle(title);
		setRating(rating);
		setReview(review);
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public float getRating() {
		return rating;
	}
	
	public void setRating(float rating) {
		this.rating = rating;
	}
	
	public String getReview() {
		return review;
	}
	
	public void setReview(String review) {
		this.review = review;
	}
	
	@Override
	public String toString() {
		return "Movie/Game ID: "+ getId() 
			 + "\nMovie/Game Title: " + getTitle() 
			 + "\nMovie/Game Rating: " + getRating() 
			 + "\nMovie/Game Review: " + getReview();
	}

}
