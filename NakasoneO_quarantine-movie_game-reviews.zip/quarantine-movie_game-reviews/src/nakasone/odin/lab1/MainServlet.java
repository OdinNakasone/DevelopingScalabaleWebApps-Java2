package nakasone.odin.lab1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import nakasone.odin.lab1.DatabaseConnection;

@WebServlet("/MainServlet")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		

		try {
			Connection con = DatabaseConnection.initializeDatabase();

			Statement statement = con.createStatement();
			ResultSet resultSet = statement.executeQuery("select * from ratings");
			

			Digitals digitals = null;
			int id;
			String data = null;
			float rating;
			String review = null;
			ArrayList<Digitals> list = new ArrayList<Digitals>();

			while (resultSet.next()) { // retrieve data
				
				id = resultSet.getInt("id");
				data = resultSet.getString("title");
				rating = resultSet.getFloat("rating");
				review = resultSet.getString("review");
				digitals = new Digitals(id, data, rating, review);
				list.add(digitals);
				request.setAttribute("digitals", list);
//f				System.out.println(digitals.toString());
				
				
				if (request.getParameter("search").equalsIgnoreCase(data) || data.toLowerCase().contains(request.getParameter("search").toLowerCase())) {
					request.setAttribute("id", digitals.getId());
					request.setAttribute("title", digitals.getTitle());
					request.setAttribute("rate", digitals.getRating());
					request.setAttribute("reviews", digitals.getReview());
					RequestDispatcher dispatcher = request.getRequestDispatcher("confirmation.jsp");
					dispatcher.forward(request, response);
					
					

				}

			}

			con.close();
			resultSet.close();

//	            request.setAttribute("readData", id);
//			System.out.println(digitals.toString());

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {

			// Initialize the database
			Connection con = DatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into demo table
			PreparedStatement pst = con.prepareStatement("insert into ratings(title, rating, review) values(?, ?, ?)");

			// Setting parameters
			pst.setString(1, request.getParameter("title"));
			pst.setFloat(2, Float.parseFloat(request.getParameter("rating")));
			pst.setString(3, request.getParameter("review"));

			// Execute the insert command using executeUpdate()
			// to make changes in database
			pst.executeUpdate();

			// Close all the connections
			pst.close();
			con.close();

			// Display the successful result
			RequestDispatcher dispatcher = request.getRequestDispatcher("confirmation.jsp");
			dispatcher.forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
