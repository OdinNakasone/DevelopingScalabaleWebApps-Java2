package nakasone.odin.fantasyWorld;


import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.query.Param;

public interface ResourceRepositoryCustom extends MongoRepository<Resource, Integer> {

	List<Resource> findByResourceWeightIsGreaterThan(float weight);

//	@Query(
//	       "SELECT s " +
//	       "FROM Resource s " +
//	       "WHERE s.resourceMaterial LIKE :t1")
	List<Resource> findByResourceMaterial(@Param("t1") String material);
	
}
