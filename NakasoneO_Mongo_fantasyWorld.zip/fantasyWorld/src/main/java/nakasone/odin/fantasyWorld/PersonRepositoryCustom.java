package nakasone.odin.fantasyWorld;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.query.Param;

public interface PersonRepositoryCustom extends MongoRepository<Person, Integer>{

	List<Person> findByPersonAgeIsGreaterThan(int age);

//	@Query(
//	       "SELECT s " +
//	       "FROM Person s " +
//	       "WHERE s.personName LIKE :t1")
	List<Person> findByPersonName(@Param("t1") String name);

	
}
