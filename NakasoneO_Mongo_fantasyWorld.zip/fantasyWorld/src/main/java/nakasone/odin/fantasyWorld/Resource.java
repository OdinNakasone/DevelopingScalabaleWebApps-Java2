package nakasone.odin.fantasyWorld;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class Resource {

	@Id
	@Indexed(unique = true)
	private int resourceId;
	private String resourceMaterial;
	private float resourceWeight;
	private boolean resourceIsRadioactive;
	private String resourceUsage;
	
//	@ManyToMany(mappedBy = "resources")
	@JsonIgnore
	private List<Animal> animals = new ArrayList<Animal>();
	
	public Resource() {
		
	}
	
	
	public Resource(int resourceId, String resourceMaterial, float resourceWeight, boolean resourceIsRadioactive,
			String resourceUsage) {
		
		setResourceId(resourceId);
		setResourceMaterial(resourceMaterial);
		setResourceWeight(resourceWeight);
		setResourceIsRadioactive(resourceIsRadioactive);
		setResourceUsage(resourceUsage);
	}


	public int getResourceId() {
		return resourceId;
	}


	public void setResourceId(int resourceId) {
		this.resourceId = resourceId;
	}


	public String getResourceMaterial() {
		return resourceMaterial;
	}


	public void setResourceMaterial(String resourceMaterial) {
		this.resourceMaterial = resourceMaterial;
	}


	public float getResourceWeight() {
		return resourceWeight;
	}


	public void setResourceWeight(float resourceWeight) {
		this.resourceWeight = resourceWeight;
	}


	public boolean isResourceIsRadioactive() {
		return resourceIsRadioactive;
	}


	public void setResourceIsRadioactive(boolean resourceIsRadioactive) {
		this.resourceIsRadioactive = resourceIsRadioactive;
	}


	public String getResourceUsage() {
		return resourceUsage;
	}


	public void setResourceUsage(String resourceUsage) {
		this.resourceUsage = resourceUsage;
	}
	
	public List<Animal> getAnimals() {
		return animals;
	}


	public void setAnimals(List<Animal> animals) {
		this.animals = animals;
	}


	@Override
	public String toString() {
		return "Resource Entity: " + "\n{" 
		 	 + "\n\tResource Id: " + getResourceId() 
			 + "\n\tType of Material: " + getResourceMaterial() 
			 + "\n\tWeight: " + getResourceWeight()
			 + "\n\tRadioactive: " + isResourceIsRadioactive()
			 + "\n\tUse for Material: " + getResourceUsage()
			 + "\n}";
			
	}
	
}
