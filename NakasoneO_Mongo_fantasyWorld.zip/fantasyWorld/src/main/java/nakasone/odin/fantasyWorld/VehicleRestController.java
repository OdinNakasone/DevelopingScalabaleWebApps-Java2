package nakasone.odin.fantasyWorld;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/vehicle")
public class VehicleRestController {

//	@Autowired
	private VehicleRepositoryCustom vehicleRepo;

	// -----------Vehicle Repository------------
	@PostMapping("")
	@ResponseStatus(code = HttpStatus.CREATED)
	public void createVehicle(@RequestBody Vehicle vehicle) {
		vehicleRepo.save(vehicle);
	}

	@GetMapping("")
	public List<Vehicle> findAllVehicles() {
		return vehicleRepo.findAll();
	}
	
	@GetMapping("/{id}")
	public List<Vehicle> findAllVehiclesById(@PathVariable int id) {
		List<Vehicle> v = new ArrayList<Vehicle>();
		v.add(vehicleRepo.findById(id).orElse(null));
		return v;
	}

	@PatchMapping("/{id}")
	@ResponseStatus(code = HttpStatus.NO_CONTENT)
	public void updateVehicle(@PathVariable int id, @RequestBody Vehicle updates) {
		Vehicle vehicle = vehicleRepo.findById(id).get();
		vehicle.setVehicleType(updates.getVehicleType());
		vehicle.setVehicleBrand(updates.getVehicleBrand());
		vehicle.setVehicleColor(updates.getVehicleColor());
		vehicle.setVehicleCanFly(updates.isVehicleCanFly());
		vehicle.setVehicleReleaseDate(updates.getVehicleReleaseDate());
		
		vehicleRepo.save(vehicle);
	}

	@DeleteMapping("/{id}")
	@ResponseStatus(code = HttpStatus.NO_CONTENT)
	public void deleteVehicle(@PathVariable int id) {
		vehicleRepo.deleteById(id);
	}
	
	@GetMapping("/searchByType/{vehicleType}")
	public List<Vehicle> searchByVehicleType(@PathVariable String vehicleType){
		return vehicleRepo.findByVehicleTypeLike(vehicleType);
	}
	
	@GetMapping("/searchByColor/{color}")
	public List<Vehicle> searchByBrand(@PathVariable String color){
		return vehicleRepo.findByVehicleColor(color);
	}

}
