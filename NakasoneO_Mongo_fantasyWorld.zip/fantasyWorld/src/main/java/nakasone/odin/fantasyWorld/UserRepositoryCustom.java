package nakasone.odin.fantasyWorld;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface UserRepositoryCustom extends MongoRepository<User, String>{
	
}
