package nakasone.odin.fantasyWorld;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;

import com.fasterxml.jackson.annotation.JsonIgnore;


public class Vehicle {

	@Id
	@Indexed(unique = true)
	private int vehicleId;
	
	private String vehicleBrand;
	private String vehicleType;
	private String vehicleColor;
	private String vehicleReleaseDate;
	private boolean vehicleCanFly;
	
//	@ManyToOne
	private Person person;
	
	public Vehicle() {
		
	}
	
	public Vehicle(int vehicleId, String vehicleBrand, String vehicleType, String vehicleColor,
			String vehcileReleaseDate, boolean vehicleCanFly) {
		setVehicleId(vehicleId);
		setVehicleBrand(vehicleBrand);
		setVehicleType(vehicleType);
		setVehicleColor(vehicleColor);
		setVehicleReleaseDate(vehcileReleaseDate);
		setVehicleCanFly(vehicleCanFly);
	}

	public int getVehicleId() {
		return vehicleId;
	}



	public void setVehicleId(int vehicleId) {
		this.vehicleId = vehicleId;
	}



	public String getVehicleBrand() {
		return vehicleBrand;
	}



	public void setVehicleBrand(String vehicleBrand) {
		this.vehicleBrand = vehicleBrand;
	}



	public String getVehicleType() {
		return vehicleType;
	}



	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}



	public String getVehicleColor() {
		return vehicleColor;
	}



	public void setVehicleColor(String vehicleColor) {
		this.vehicleColor = vehicleColor;
	}



	public String getVehicleReleaseDate() {
		return vehicleReleaseDate;
	}



	public void setVehicleReleaseDate(String vehicleReleaseDate) {
		this.vehicleReleaseDate = vehicleReleaseDate;
	}



	public boolean isVehicleCanFly() {
		return vehicleCanFly;
	}



	public void setVehicleCanFly(boolean vehicleCanFly) {
		this.vehicleCanFly = vehicleCanFly;
	}
	
	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

	@Override
	public String toString() {
		return "Vehicle Entity: " + "\n{" 
			 + "\n\tVehicle Id: " + getVehicleId() 
			 + "\n\tBrand: " + getVehicleBrand() 
			 + "\n\tVehicle Type: " + getVehicleType()
			 + "\n\tColor: " + getVehicleColor()
			 + "\n\tRelease Date: " + getVehicleReleaseDate()
			 + "\n\tAbility to Fly: " + isVehicleCanFly() 
			 + "\n}";
	}
	
}
