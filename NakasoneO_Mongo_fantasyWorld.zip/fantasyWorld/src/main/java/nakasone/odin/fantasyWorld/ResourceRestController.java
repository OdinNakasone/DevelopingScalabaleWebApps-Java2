package nakasone.odin.fantasyWorld;

import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/resource")
public class ResourceRestController {

	@Autowired
	private ResourceRepositoryCustom resourceRepo;

	// -----------Resource Repository------------
	@PostMapping("")
	@ResponseStatus(code = HttpStatus.CREATED)
	public void createResource(@RequestBody Resource resource) {
		resourceRepo.save(resource);
	}

	@GetMapping("")
	public List<Resource> findAllResources() {
		return resourceRepo.findAll();
	}
	
	@GetMapping("/{id}")
	public List<Resource> findAllResourcesById(@PathVariable int id) {
		List<Resource> r = new ArrayList<Resource>();
		r.add(resourceRepo.findById(id).orElse(null));
		return r;
	}

	@PatchMapping("/{id}")
	@ResponseStatus(code = HttpStatus.NO_CONTENT)
	public void updateResource(@PathVariable int id, @RequestBody Resource updates) {
		Resource resource = resourceRepo.findById(id).get();
		resource.setResourceMaterial(updates.getResourceMaterial());
		resource.setResourceUsage(updates.getResourceUsage());
		resource.setResourceIsRadioactive(updates.isResourceIsRadioactive());
		resource.setResourceWeight(updates.getResourceWeight());
		
		resourceRepo.save(resource);
	}

	@DeleteMapping("/{id}")
	@ResponseStatus(code = HttpStatus.NO_CONTENT)
	public void deleteResouce(@PathVariable int id) {
		resourceRepo.deleteById(id);
	}
	
	@GetMapping("/searchByWeight/{weight}")
	public List<Resource> searchByType(@PathVariable float weight){
		return resourceRepo.findByResourceWeightIsGreaterThan(weight);
	}
	
	@GetMapping("/searchByMaterial/{material}")
	public List<Resource> searchByBrand(@PathVariable String material){
		return resourceRepo.findByResourceMaterial(material);
	}

}
