package nakasone.odin.fantasyWorld;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")
public class UserRestController {

	@Autowired
	private UserRepositoryCustom userRepo;

	// -----------User Repository------------
	@PostMapping("")
	@ResponseStatus(code = HttpStatus.CREATED)
	public void createUser(@RequestBody User user) {

		if(!user.getPassword().startsWith("$2a")) {
			user.setPassword(passwordEncoder().encode(user.getPassword()));
		}
		userRepo.save(user);
	}
	
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@PatchMapping("/grant/{username}/{authority}")
	@ResponseStatus(code = HttpStatus.NO_CONTENT)
	public void grantAuthority(@PathVariable String username, @PathVariable String authority) {
		User u = userRepo.findById(username).orElse(null);
		userRepo.deleteById(username);
		u.getAuthoritiesAsStrings().add(authority);
		userRepo.save(u);
	}
	@GetMapping(path = "/auth")
    public String login(){ return "Authenticated";}

//	@RequestMapping(path = "", method = RequestMethod.GET)
//	public List<User> findAllUsers() {
//		return userRepo.findAllUsers();
//	}
//	
//	@RequestMapping(path = "/{id}", method = RequestMethod.GET)
//	public List<User> findAllUsersById(@PathVariable int id) {
//		return userRepo.findAllUsersById(id);
//	}
//
//	@RequestMapping(path = "/{id}", method = RequestMethod.PATCH)
//	public void updateUser(@PathVariable int id) {
//		userRepo.updateUser(id);
//	}
//
//	@RequestMapping(path = "/{id}", method = RequestMethod.DELETE)
//	public void deleteUser(@PathVariable int id) {
//		userRepo.deleteUser(id);
//	}

}
