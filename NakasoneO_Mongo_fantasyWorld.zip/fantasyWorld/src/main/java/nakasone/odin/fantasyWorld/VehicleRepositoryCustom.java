package nakasone.odin.fantasyWorld;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.query.Param;

public interface VehicleRepositoryCustom extends MongoRepository<Vehicle, Integer>{

	List<Vehicle> findByVehicleTypeLike(String vehicleType);

//	@Query(
//			"SELECT s " +
//			"FROM Vehicle s " +
//			"WHERE s.vehicleColor LIKE :t1")
	List<Vehicle> findByVehicleColor(@Param("t1") String color);
	
}


