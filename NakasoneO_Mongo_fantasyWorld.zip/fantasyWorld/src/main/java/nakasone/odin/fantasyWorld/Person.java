package nakasone.odin.fantasyWorld;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class Person {

	@Id
	@Indexed(unique = true)
	private int personId;
	
	private String personName;
	private int personAge;
	private String personPlaceOfOrigin;
	private String personGender;
	private String personOccupation;
	
//	@OneToMany
	private List<Vehicle> vehicles = new ArrayList<Vehicle>();
	
	public Person() {
		
	}
	
	
	
	public Person(int personId, String personName, int personAge, String personPlaceOfOrigin, String personGender,
			String personOccupation) {
		
		setPersonId(personId);
		setPersonName(personName);
		setPersonAge(personAge);
		setPersonPlaceOfOrigin(personPlaceOfOrigin);
		setPersonGender(personGender);
		setPersonOccupation(personOccupation);
	}



	public int getPersonId() {
		return personId;
	}




	public void setPersonId(int personId) {
		this.personId = personId;
	}




	public String getPersonName() {
		return personName;
	}




	public void setPersonName(String personName) {
		this.personName = personName;
	}




	public int getPersonAge() {
		return personAge;
	}




	public void setPersonAge(int personAge) {
		this.personAge = personAge;
	}




	public String getPersonPlaceOfOrigin() {
		return personPlaceOfOrigin;
	}




	public void setPersonPlaceOfOrigin(String personPlaceOfOrigin) {
		this.personPlaceOfOrigin = personPlaceOfOrigin;
	}




	public String getPersonGender() {
		return personGender;
	}




	public void setPersonGender(String personGender) {
		this.personGender = personGender;
	}




	public String getPersonOccupation() {
		return personOccupation;
	}




	public void setPersonOccupation(String personOccupation) {
		this.personOccupation = personOccupation;
	}
	


	public List<Vehicle> getVehicles() {
		return vehicles;
	}



	public void setVehicles(List<Vehicle> vehicles) {
		this.vehicles = vehicles;
	}



	@Override
	public String toString() {
		return "Person Entity: " + "\n{" 
				 + "\n\tPerson Id: " + getPersonId() 
				 + "\n\tName: " + getPersonName() 
				 + "\n\tAge: " + getPersonAge()
				 + "\n\tPlace of Origin: " + getPersonPlaceOfOrigin()
				 + "\n\tGender: " + getPersonGender()
				 + "\n\tOccupation: " + getPersonOccupation() 
				 + "\n}";
	}
}
