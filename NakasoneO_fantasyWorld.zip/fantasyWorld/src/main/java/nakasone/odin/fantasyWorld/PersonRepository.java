package nakasone.odin.fantasyWorld;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class PersonRepository {

	private List<Person> people = new ArrayList<Person>();

	public void createPerson(Person person) {

		try {
			System.out.println(person.toString());

			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into table
			PreparedStatement pst = con.prepareStatement("insert into person values(?, ?, ?, ?, ?, ?)");

			pst.setInt(1, person.getPersonId());
			pst.setString(2, person.getPersonName());
			pst.setInt(3, person.getPersonAge());
			pst.setString(4, person.getPersonPlaceOfOrigin());
			pst.setString(5, person.getPersonGender());
			pst.setString(6, person.getPersonOccupation());

			// Execute the insert command using executeUpdate()
			// to make changes in database
			pst.executeUpdate();

			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		people.add(person);
	}

	public List<Person> findAllPeople() {
		return people;

	}

	public Optional<Person> findPersonById(int id) {
		return people.stream().filter(person -> person.getPersonId() == id).findFirst();
	}

	public void updatePerson() {
		try {

			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into demo table
			String sql = "UPDATE person " + "SET person_age = ? WHERE person_id = 1";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, 69);

			// Execute the insert command using executeUpdate()
			// to make changes in database
			pst.executeUpdate();

			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void deletePerson() {

		try {

			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into demo table
			String sql = "DELETE FROM person " + "WHERE person_id = 1";
			PreparedStatement pst = con.prepareStatement(sql);

			// Execute the insert command using executeUpdate()
			// to make changes in database
			pst.executeUpdate();

			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
