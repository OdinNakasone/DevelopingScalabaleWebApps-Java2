package nakasone.odin.fantasyWorld;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class AnimalRepository {

	private List<Animal> animals = new ArrayList<Animal>();

	public void createAnimal(Animal animal) {
//		if(animals.stream().filter(a -> a.getId() == animal.getId()).count() > 0) {
//			throw new RuntimeException("The id" + animal.getId() + " already exists");
//		}
		try {
			System.out.println(animal.toString());

			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into table
			PreparedStatement pst = con.prepareStatement("insert into animal values(?, ?, ?, ?, ?, ?)");

			pst.setInt(1, animal.getAnimalId());
			pst.setString(2, animal.getAnimalName());
			pst.setString(3, animal.getAnimalType());
			pst.setString(4, animal.getAnimalGender());
			pst.setInt(5, animal.getAnimalAppendages());
			pst.setString(6, String.valueOf(animal.isAnimalFly()));

			// Execute the insert command using executeUpdate()
			// to make changes in database
			pst.executeUpdate();

			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		animals.add(animal);
	}

	public List<Animal> findAllAnimals() {
		return animals;

	}

	public Optional<Animal> findAnimalById(int id) {
		return animals.stream().filter(animal -> animal.getAnimalId() == id).findFirst();
	}

	public void updateAnimal() {

		try {

			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into demo table
			String sql = "UPDATE animal " + "SET animal_name = ? WHERE animal_id = 1";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, "ChangedAnimalName");
		

			// Execute the insert command using executeUpdate()
			// to make changes in database
			pst.executeUpdate();

			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void deleteAnimal() {

		try {

			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into demo table
			String sql = "DELETE FROM animal " + "WHERE animal_id = 1";
			PreparedStatement pst = con.prepareStatement(sql);

			// Execute the insert command using executeUpdate()
			// to make changes in database
			pst.executeUpdate();

			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
