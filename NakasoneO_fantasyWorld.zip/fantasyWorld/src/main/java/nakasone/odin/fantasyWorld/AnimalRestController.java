package nakasone.odin.fantasyWorld;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/animal")
public class AnimalRestController {

	@Autowired
	private AnimalRepository animalRepo;

	// -----------Animal Repository------------
	@RequestMapping(path = "", method = RequestMethod.POST)
	public void createAnimal(@RequestBody Animal animal) {
		animalRepo.createAnimal(animal);
	}

	@RequestMapping(path = "", method = RequestMethod.GET)
	public List<Animal> findAllAnimals() {
		return animalRepo.findAllAnimals();
	}

	@RequestMapping(path = "", method = RequestMethod.PATCH)
	public void updateAnimal() {
		animalRepo.updateAnimal();
	}

	@RequestMapping(path = "", method = RequestMethod.DELETE)
	public void deleteAnimal() {
		animalRepo.deleteAnimal();
	}

}
