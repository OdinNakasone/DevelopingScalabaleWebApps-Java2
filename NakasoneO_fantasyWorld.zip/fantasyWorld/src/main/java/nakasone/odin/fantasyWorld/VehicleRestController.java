package nakasone.odin.fantasyWorld;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/vehicle")
public class VehicleRestController {

	@Autowired
	private VehicleRepository vehicleRepo;

	// -----------Vehicle Repository------------
	@RequestMapping(path = "", method = RequestMethod.POST)
	public void createVehicle(@RequestBody Vehicle vehicle) {
		vehicleRepo.createVehicle(vehicle);
	}

	@RequestMapping(path = "", method = RequestMethod.GET)
	public List<Vehicle> findAllVehicles() {
		return vehicleRepo.findAllVehicles();
	}

	@RequestMapping(path = "", method = RequestMethod.PATCH)
	public void updateVehicle() {
		 vehicleRepo.updateVehicle();
	}

	@RequestMapping(path = "", method = RequestMethod.DELETE)
	public void deleteVehicle() {
		 vehicleRepo.deleteVehicle();
	}

}
