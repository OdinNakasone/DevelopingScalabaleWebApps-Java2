package nakasone.odin.fantasyWorld;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AnimalConfiguration {
	
	@Bean
	public AnimalRepository animalRepository() {
		return new AnimalRepository();
	}

}
