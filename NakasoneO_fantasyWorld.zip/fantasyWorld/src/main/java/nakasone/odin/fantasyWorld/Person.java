package nakasone.odin.fantasyWorld;

public class Person {

	private int personId;
	private String personName;
	private int personAge;
	private String personPlaceOfOrigin;
	private String personGender;
	private String personOccupation;
	
	public Person() {
		
	}
	
	
	
	public Person(int personId, String personName, int personAge, String personPlaceOfOrigin, String personGender,
			String personOccupation) {
		
		setPersonId(personId);
		setPersonName(personName);
		setPersonAge(personAge);
		setPersonPlaceOfOrigin(personPlaceOfOrigin);
		setPersonGender(personGender);
		setPersonOccupation(personOccupation);
	}



	public int getPersonId() {
		return personId;
	}




	public void setPersonId(int personId) {
		this.personId = personId;
	}




	public String getPersonName() {
		return personName;
	}




	public void setPersonName(String personName) {
		this.personName = personName;
	}




	public int getPersonAge() {
		return personAge;
	}




	public void setPersonAge(int personAge) {
		this.personAge = personAge;
	}




	public String getPersonPlaceOfOrigin() {
		return personPlaceOfOrigin;
	}




	public void setPersonPlaceOfOrigin(String personPlaceOfOrigin) {
		this.personPlaceOfOrigin = personPlaceOfOrigin;
	}




	public String getPersonGender() {
		return personGender;
	}




	public void setPersonGender(String personGender) {
		this.personGender = personGender;
	}




	public String getPersonOccupation() {
		return personOccupation;
	}




	public void setPersonOccupation(String personOccupation) {
		this.personOccupation = personOccupation;
	}




	@Override
	public String toString() {
		return "Person Entity: " + "\n{" 
				 + "\n\tPerson Id: " + getPersonId() 
				 + "\n\tName: " + getPersonName() 
				 + "\n\tAge: " + getPersonAge()
				 + "\n\tPlace of Origin: " + getPersonPlaceOfOrigin()
				 + "\n\tGender: " + getPersonGender()
				 + "\n\tOccupation: " + getPersonOccupation() 
				 + "\n}";
	}
}
