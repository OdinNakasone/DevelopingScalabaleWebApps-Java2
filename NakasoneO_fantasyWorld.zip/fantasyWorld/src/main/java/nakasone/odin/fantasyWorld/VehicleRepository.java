package nakasone.odin.fantasyWorld;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;



public class VehicleRepository {
	
	private List<Vehicle> vehicles = new ArrayList<Vehicle>();
	
	public void createVehicle(Vehicle vehicle) {
		
		try {
			System.out.println(vehicles.toString());

			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into table
			PreparedStatement pst = con.prepareStatement("insert into vehicle values(?, ?, ?, ?, ?, ?)");
			pst.setInt(1, vehicle.getVehicleId());
			pst.setString(2, vehicle.getVehicleBrand());
			pst.setString(3, vehicle.getVehicleType());
			pst.setString(4, vehicle.getVehicleColor());
			pst.setString(5, vehicle.getVehicleReleaseDate());
			pst.setString(6, String.valueOf(vehicle.isVehicleCanFly()));

			

			// Execute the insert command using executeUpdate()
			// to make changes in database
			pst.executeUpdate();

			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		vehicles.add(vehicle);
	}
	
	
	public List<Vehicle> findAllVehicles(){
		return vehicles;
		
	}
	
	public Optional<Vehicle> findByVehicleId(int id) {
		return vehicles.stream().filter(vehicle -> vehicle.getVehicleId() == id).findFirst();
		
	}
	
	public void updateVehicle(){
		
		try {

			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into demo table
			String sql = "UPDATE vehicle " + "SET vehicle_brand = ? WHERE vehicle_id = 1";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, "ChangedVehicleBrand");

			// Execute the insert command using executeUpdate()
			// to make changes in database
			pst.executeUpdate();

			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void deleteVehicle() {
	

		try {

			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into demo table
			String sql = "DELETE FROM vehicle " + "WHERE vehicle_id = 1";
			PreparedStatement pst = con.prepareStatement(sql);

			// Execute the insert command using executeUpdate()
			// to make changes in database
			pst.executeUpdate();

			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}


