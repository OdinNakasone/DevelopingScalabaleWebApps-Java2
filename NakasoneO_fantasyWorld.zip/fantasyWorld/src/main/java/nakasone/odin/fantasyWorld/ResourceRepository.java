package nakasone.odin.fantasyWorld;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ResourceRepository {

	private List<Resource> resources = new ArrayList<Resource>();

	public void createResource(Resource resource) {
		try {
			System.out.println(resource.toString());

			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into table
			PreparedStatement pst = con.prepareStatement("insert into resource values(?, ?, ?, ?, ?)");

			pst.setInt(1, resource.getResourceId());
			pst.setString(2, resource.getResourceMaterial());
			pst.setFloat(3, resource.getResourceWeight());
			pst.setString(4, String.valueOf(resource.isResourceIsRadioactive()));
			pst.setString(5, resource.getResourceUsage());

			// Execute the insert command using executeUpdate()
			// to make changes in database
			pst.executeUpdate();

			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		resources.add(resource);
	}

	public List<Resource> findAllResources() {
		return resources;

	}

	public Optional<Resource> findResourceById(int id) {
		return resources.stream().filter(resource -> resource.getResourceId() == id).findFirst();
	}

	public void updateResource() {

		try {

			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into demo table
			String sql = "UPDATE resource " + "SET resource_type = ? WHERE resource_id = 1";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, "ChangedResourceName");

			// Execute the insert command using executeUpdate()
			// to make changes in database
			pst.executeUpdate();

			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void deleteResource() {

		try {

			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into demo table
			String sql = "DELETE FROM resource " + "WHERE resource_id = 1";
			PreparedStatement pst = con.prepareStatement(sql);

			// Execute the insert command using executeUpdate()
			// to make changes in database
			pst.executeUpdate();

			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
