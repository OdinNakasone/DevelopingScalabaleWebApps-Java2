package nakasone.odin.fantasyWorld;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FantasyWorldApplicationTests {

	@Test
	void contextLoads() {
	}

}
