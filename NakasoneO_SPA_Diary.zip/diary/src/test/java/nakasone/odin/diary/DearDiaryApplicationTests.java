package nakasone.odin.diary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DearDiaryApplicationTests {

	@Test
	void contextLoads() {
	}

}
