package nakasone.odin.diary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DearDiaryApplication {

	public static void main(String[] args) {
		SpringApplication.run(DearDiaryApplication.class, args);
	}

}
