package nakasone.odin.fantasyWorld;


import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
@EnableWebSecurity
public class FantasySecurityConfiguration extends WebSecurityConfigurerAdapter {
	
	public static final String AUTH_USER = "USER";
	public static final String AUTH_ADMIN = "ADMIN";
	
	@Autowired
	private UserRepository userRepo;
	
//  @PostConstruct
//  public void init(){
//      userRepo.save(new User("admin", passwordEncoder().encode("testtest1"),"USER","ADMIN"));
//  }
	
	@Bean
	public UserDetailsService userDetailService() {
		return username -> {
			return userRepo.findById(username).orElse(null);
		};
	}
	

//	@Override
//	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
//		auth.inMemoryAuthentication().withUser("user1").password(passwordEncoder().encode("pass1")).authorities("USER");
//	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests()
		.antMatchers("/animal/**", "/person/**", "/resource/**", "/vehicle/**", "/index.html").permitAll()
		.antMatchers("/user").hasAnyAuthority(AUTH_ADMIN, AUTH_ADMIN + ", " + AUTH_USER)
		.antMatchers("/user/grant/{username}/{authority}").hasAnyAuthority(AUTH_ADMIN, AUTH_ADMIN + ", " + AUTH_USER)
		.anyRequest().authenticated()
		.and().sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
		.and()
		.httpBasic();
		http.csrf().disable();
	}
	
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}


	

	public static void validateAuthorityExists(String authority) {
		// TODO Auto-generated method stub
		
	}

}
