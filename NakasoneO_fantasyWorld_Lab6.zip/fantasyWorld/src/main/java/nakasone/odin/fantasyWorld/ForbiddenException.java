package nakasone.odin.fantasyWorld;

public class ForbiddenException extends IllegalArgumentException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
