package nakasone.odin.fantasyWorld;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface VehicleRepository extends JpaRepository<Vehicle, Integer>{

	List<Vehicle> findByVehicleTypeLike(String vehicleType);

	@Query(
			"SELECT s " +
			"FROM Vehicle s " +
			"WHERE s.vehicleColor LIKE :t1")
	List<Vehicle> findByColor(@Param("t1") String color);
	
}


