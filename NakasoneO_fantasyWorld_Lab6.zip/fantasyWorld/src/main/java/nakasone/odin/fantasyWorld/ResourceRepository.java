package nakasone.odin.fantasyWorld;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ResourceRepository extends JpaRepository<Resource, Integer> {

	List<Resource> findByResourceWeightIsGreaterThan(float weight);

	@Query(
	       "SELECT s " +
	       "FROM Resource s " +
	       "WHERE s.resourceMaterial LIKE :t1")
	List<Resource> findByMaterial(@Param("t1") String material);
	
}
