package nakasone.odin.fantasyWorld;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Animal {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int animalId;
	private String animalName;
	private String animalType;
	private String animalGender;
	private int animalAppendages;
	private boolean animalFly;
	
	@ManyToMany
	private List<Resource> resources = new ArrayList<Resource>();
	
	
	public Animal() {
		
	}
	
	public Animal(int id, String name, String animalType, String gender, int numOfAppendages, boolean canFly) {
		setAnimalId(id);
		setAnimalName(name);
		setAnimalType(animalType);
		setAnimalGender(gender);
		setAnimalAppendages(numOfAppendages);
		setAnimalFly(canFly);
	}
	
	public int getAnimalId() {
		return animalId;
	}

	public void setAnimalId(int animalId) {
		this.animalId = animalId;
	}

	public String getAnimalName() {
		return animalName;
	}

	public void setAnimalName(String animalName) {
		this.animalName = animalName;
	}

	public String getAnimalType() {
		return animalType;
	}

	public void setAnimalType(String animalType) {
		this.animalType = animalType;
	}

	public String getAnimalGender() {
		return animalGender;
	}

	public void setAnimalGender(String animalGender) {
		this.animalGender = animalGender;
	}

	public int getAnimalAppendages() {
		return animalAppendages;
	}

	public void setAnimalAppendages(int animalAppendages) {
		this.animalAppendages = animalAppendages;
	}

	public boolean isAnimalFly() {
		return animalFly;
	}

	public void setAnimalFly(boolean animalFly) {
		this.animalFly = animalFly;
	}
	
	
	public List<Resource> getResources() {
		return resources;
	}

	public void setResources(List<Resource> resources) {
		this.resources = resources;
	}

	@Override
	public String toString() {
		return "Animal Entity " + "\n{" 
			 + "\n\tAnimal Id: " + getAnimalId() 
			 + "\n\tName: " + getAnimalName() 
			 + "\n\tType of Animal: " + getAnimalType()
			 + "\n\tNumber of Appendages: " + getAnimalAppendages()
			 + "\n\tFlying Ability: " + isAnimalFly()
			 + "\n\tGender: " + getAnimalGender()
			 + "\n}";
	}

	
	
	

}
