package nakasone.odin.fantasyWorld;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


public interface AnimalRepository extends JpaRepository<Animal, Integer> {

	List<Animal> findByAnimalAppendagesIsLessThan(int appendages);

	@Query(
           "SELECT s " +
           "FROM Animal s " +
           "WHERE s.animalName LIKE :t1")
	List<Animal> findByName(@Param("t1") String name);

}
