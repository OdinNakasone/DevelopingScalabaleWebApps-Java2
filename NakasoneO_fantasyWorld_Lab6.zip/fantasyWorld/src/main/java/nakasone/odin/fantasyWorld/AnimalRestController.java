package nakasone.odin.fantasyWorld;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/animal")
public class AnimalRestController {

	@Autowired
	private AnimalRepository animalRepo;
	
	@Autowired
	private ResourceRepository resourceRepo;

	// -----------Animal Repository------------
	@PostMapping("")
	@ResponseStatus(code = HttpStatus.CREATED)
	public void createAnimal(@RequestBody Animal animal) {
		animalRepo.save(animal);
	}

	@GetMapping("")
	public List<Animal> findAllAnimals() {
		return animalRepo.findAll();
	}
	
	@GetMapping("/{id}")
	public List<Animal> findAllAnimalsById(@PathVariable int id) {
		List<Animal> a1 = new ArrayList<>();
		a1.add(animalRepo.findById(id).orElse(null));
		return a1;
		
	}

	@PatchMapping("/{id}")
	@Transactional
	@ResponseStatus(code = HttpStatus.NO_CONTENT)
	public void updateAnimal(@PathVariable int id, @RequestBody Animal updates) {
		Animal animal = animalRepo.findById(id).get();
		animal.setAnimalType(updates.getAnimalType());
		animal.setAnimalAppendages(updates.getAnimalAppendages());
		animal.setAnimalFly(updates.isAnimalFly());
		animal.setAnimalGender(updates.getAnimalGender());
		animal.setAnimalName(updates.getAnimalName());
		animalRepo.save(animal);
	}
	
	@PutMapping("/{animalId}/addResource/{resourceId}")
    @ResponseStatus(code=HttpStatus.NO_CONTENT)
    @Transactional
    public void addResourceToAnimal(
            @PathVariable int animalId,
            @PathVariable int resourceId) {

        Resource r = resourceRepo.findById(resourceId).get();
        Animal a = animalRepo.findById(animalId).orElse(null);
        a.getResources().add(r);
        animalRepo.save(a);
    }

	@DeleteMapping("/{id}")
	@ResponseStatus(code = HttpStatus.NO_CONTENT)
	public void deleteAnimal(@PathVariable int id) {
		animalRepo.deleteById(id);
	}
	
	@GetMapping("/searchByAppendages/{appendages}")
	public List<Animal> searchByAppendages(@PathVariable int appendages){
		return animalRepo.findByAnimalAppendagesIsLessThan(appendages);
	}
	
	@GetMapping("/searchByName/{name}")
	public List<Animal> searchByName(@PathVariable String name){
		return animalRepo.findByName(name);
	}

}
