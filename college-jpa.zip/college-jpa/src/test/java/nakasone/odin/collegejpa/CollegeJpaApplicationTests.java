package nakasone.odin.collegejpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollegeJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
