package nakasone.odin.collegejpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollegeJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CollegeJpaApplication.class, args);
	}

}
