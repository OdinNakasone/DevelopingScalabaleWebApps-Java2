package nakasone.odin.collegejpa.model;

import org.springframework.data.jpa.repository.JpaRepository;

public interface InstructorJpaRepository extends JpaRepository<Instructor, Integer> {

}
