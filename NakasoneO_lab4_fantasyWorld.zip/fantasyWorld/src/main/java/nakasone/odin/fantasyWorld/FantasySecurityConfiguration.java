package nakasone.odin.fantasyWorld;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
@EnableWebSecurity
public class FantasySecurityConfiguration extends WebSecurityConfigurerAdapter {
	
	private List<User> users = new ArrayList<User>();
	
	public static final String AUTH_USER = "USER";
	public static final String AUTH_ADMIN = "ADMIN";
	
	@Autowired
	private UserRepository userRepo;
	
	@Bean
	public UserDetailsService userDetailService() {
		return new UserDetailsService() {
			
			@Override
			public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
				users.clear();
				try {

					// Initialize the database
					Connection con = FantasyDatabaseConnection.initializeDatabase();

					// Create a SQL query to insert data into demo table
					String sql = "SELECT * FROM fantasy_world.user WHERE user_username = " + "'" + username + "'";
					PreparedStatement pst = con.prepareStatement(sql);
					ResultSet res = pst.executeQuery();

					while (res.next()) { // retrieve data

						int id = res.getInt(1);
						String u_username = res.getString(2);
						String password = res.getString(3);
						String authorities = res.getString(4);

//						users.add(new User(id, u_username, password, authorities));
						return new User(id, u_username,  passwordEncoder().encode(password), authorities);


					}
					// Close all the connections
					pst.close();
					con.close();

				} catch (Exception e) {
					e.printStackTrace();
				}
				return null;
			}
		};
	}
	

//	@Override
//	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
//		auth.inMemoryAuthentication().withUser("user1").password(passwordEncoder().encode("pass1")).authorities("USER");
//	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests()
		.antMatchers("/animal", "/person", "/resource", "/vehicle", "/index.html").permitAll()
		.antMatchers("/user").hasAnyAuthority(AUTH_ADMIN, AUTH_ADMIN + ", " + AUTH_USER)
		.antMatchers("/user/grant/{username}/{authority}").hasAnyAuthority(AUTH_ADMIN, AUTH_ADMIN + ", " + AUTH_USER)
		.anyRequest().authenticated()
		.and().sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
		.and()
		.httpBasic();
		http.csrf().disable();
	}
	
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}


	

	public static void validateAuthorityExists(String authority) {
		// TODO Auto-generated method stub
		
	}

}
