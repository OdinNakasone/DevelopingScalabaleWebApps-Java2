package nakasone.odin.fantasyWorld;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

//@ControllerAdvice
public class ExceptionHandlerConfig extends ResponseEntityExceptionHandler {
//	
//	@ExceptionHandler(RuntimeException.class)
//	protected ResponseEntity<ResponseBody> handleRuntimeException(RuntimeException run, WebRequest request){
//		ResponseBody responseBody = new ResponseBody();
//		responseBody.setCode("UNAUTHENTICATED");
//		responseBody.setMessage("You have hit a runtime excpetion");
//		
//		ResponseEntity<ResponseBody> response = new ResponseEntity<>(responseBody, HttpStatus.UNAUTHORIZED);
//		return response;
//	}
//	
//	@ExceptionHandler(RuntimeException.class)
//	protected ResponseEntity<ResponseBody> handleCustomException(ForbiddenException forb, WebRequest request){
//		ResponseBody responseBody = new ResponseBody();
//		responseBody.setCode("FORBIDDEN");
//		responseBody.setMessage("You do not have the authority to make this request");
//		
//		ResponseEntity<ResponseBody> response = new ResponseEntity<>(responseBody, HttpStatus.FORBIDDEN);
//		return response;
//	}
//	
//	public static class ResponseBody{
//		private String code;
//		private String message;
//		
//			
//		public String getCode() {
//			return code;
//		}
//		public void setCode(String code) {
//			this.code = code;
//		}
//		public String getMessage() {
//			return message;
//		}
//		public void setMessage(String message) {
//			this.message = message;
//		}
//		
//		
//	}


}
