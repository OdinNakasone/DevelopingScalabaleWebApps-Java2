package nakasone.odin.fantasyWorld;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class UserRepository {
	private List<User> users = new ArrayList<User>();
	
	public String[] getStringArray(List<String> list) 
    { 
  
       
        String str[] = new String[list.size()]; 
  
        // ArrayList to Array Conversion 
        for (int j = 0; j < list.size(); j++) { 
  
            // Assign each value to String array 
            str[j] = list.get(j); 
        } 
  
        return str; 
    } 

	public void createUser(User user) {
		try {

			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into table
			PreparedStatement pst = con.prepareStatement("insert into user values(?, ?, ?, ?)");
			String[] auth = getStringArray(user.getAuthoritiesAsStrings());
			pst.setInt(1, user.getId());
			pst.setString(2, user.getUsername());
			pst.setString(3, user.getPassword());
			pst.setString(4, Arrays.toString(auth).replace("[", "").replace("]", ""));

			// Execute the insert command using executeUpdate()
			// to make changes in database
			pst.executeUpdate();

			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		users.add(user);
	}

	public List<User> findAllUsers() {
		users.clear();
		try {

			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into demo table
			String sql = "SELECT * FROM user";
			PreparedStatement pst = con.prepareStatement(sql);
			ResultSet res = pst.executeQuery();

			while (res.next()) { // retrieve data

				int id = res.getInt(1);
				String username = res.getString(2);
				String password = res.getString(3);
				String authorities = res.getString(4);

				users.add(new User(id, username, password, authorities));

//				System.out.println(animals.toString());

			}
			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return users;

	}

	public List<User> findAllUsersById(int id) {

		findAllUsers();
		List<User> result = new ArrayList<User>();
		User u = users.stream().filter(user -> user.getId() == id).findFirst().orElse(null);
		result.add(u);
		return result;

	}
	
	public User findAllUsersByUsername(String username) {

		findAllUsers();
		
		User u = users.stream().filter(user -> user.getUsername().equals(username)).findFirst().orElse(null);
		
		return u;

	}

	public void updateUser(String username, String authority) {
		try {

			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into demo table
			String sql = "UPDATE user " + "SET user_authorities = ? WHERE user_username = ?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, authority);
			pst.setString(2, username);

			// Execute the insert command using executeUpdate()
			// to make changes in database
			pst.executeUpdate();

			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
//
//	public void deleteUser(int id) {
//
//	}
}
