package nakasone.odin.fantasyWorld;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")
public class UserRestController {

	@Autowired
	private UserRepository userRepo;

	// -----------User Repository------------
	@RequestMapping(path = "", method = RequestMethod.POST)
	public void createUser(@RequestBody User user) {

		userRepo.createUser(user);

	}

	@RequestMapping(path = "/grant/{username}/{authority}", method = RequestMethod.PATCH)
	public void grantAuthority(@PathVariable String username, @PathVariable String authority) {
//		User u = userRepo.findAllUsersByUsername(username);
//		FantasySecurityConfiguration.validateAuthorityExists(authority);
//		u.getAuthoritiesAsStrings().add(authority);
//		userRepo.createUser(u);
		userRepo.updateUser(username, authority);
	}

//	@RequestMapping(path = "", method = RequestMethod.GET)
//	public List<User> findAllUsers() {
//		return userRepo.findAllUsers();
//	}
//	
//	@RequestMapping(path = "/{id}", method = RequestMethod.GET)
//	public List<User> findAllUsersById(@PathVariable int id) {
//		return userRepo.findAllUsersById(id);
//	}
//
//	@RequestMapping(path = "/{id}", method = RequestMethod.PATCH)
//	public void updateUser(@PathVariable int id) {
//		userRepo.updateUser(id);
//	}
//
//	@RequestMapping(path = "/{id}", method = RequestMethod.DELETE)
//	public void deleteUser(@PathVariable int id) {
//		userRepo.deleteUser(id);
//	}

}
