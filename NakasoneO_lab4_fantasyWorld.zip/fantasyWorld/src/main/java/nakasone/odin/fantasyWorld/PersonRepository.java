package nakasone.odin.fantasyWorld;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class PersonRepository {

	private List<Person> people = new ArrayList<Person>();

	public void createPerson(Person person) {

		try {
		

			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into table
			PreparedStatement pst = con.prepareStatement("insert into person values(?, ?, ?, ?, ?, ?)");

			pst.setInt(1, person.getPersonId());
			pst.setString(2, person.getPersonName());
			pst.setInt(3, person.getPersonAge());
			pst.setString(4, person.getPersonPlaceOfOrigin());
			pst.setString(5, person.getPersonGender());
			pst.setString(6, person.getPersonOccupation());

			// Execute the insert command using executeUpdate()
			// to make changes in database
			pst.executeUpdate();

			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		people.add(person);
	}

	public List<Person> findAllPeople() {
		people.clear();
		try {

			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into demo table
			String sql = "SELECT * FROM person";
			PreparedStatement pst = con.prepareStatement(sql);
			ResultSet res = pst.executeQuery();

			while (res.next()) { // retrieve data
				
				int id = res.getInt(1);
				String name = res.getString(2);
				int age = res.getInt(3);
				String origin = res.getString(4);
				String gender = res.getString(5);
				String occupation = res.getString(6);
				
				people.add(new Person(id, name, age, origin, gender, occupation));
				
//				System.out.println(animals.toString());

			}
			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return people;


	}

	public List<Person> findAllPeopleById(int id) {
		findAllPeople();
		List<Person> result = new ArrayList<Person>();
		Person p = people.stream().filter(person -> person.getPersonId() == id).findFirst().orElse(null);
		result.add(p);
		return result;
	}

	public void updatePerson(int id) {
		try {

			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into demo table
			String sql = "UPDATE person " + "SET person_age = ? WHERE person_id = ?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, 69);
			pst.setInt(2, id);

			// Execute the insert command using executeUpdate()
			// to make changes in database
			pst.executeUpdate();

			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void deletePerson(int id) {

		try {

			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into demo table
			String sql = "DELETE FROM person " + "WHERE person_id = ?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, id);

			// Execute the insert command using executeUpdate()
			// to make changes in database
			pst.executeUpdate();

			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
