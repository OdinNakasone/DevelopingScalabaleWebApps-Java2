package nakasone.odin.fantasyWorld;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/person")
public class PersonRestController {

	@Autowired
	private PersonRepository personRepo;

	// -----------People Repository------------
	@RequestMapping(path = "", method = RequestMethod.POST)
	public void createPerson(@RequestBody Person person) {
		personRepo.createPerson(person);
	}

	@RequestMapping(path = "", method = RequestMethod.GET)
	public List<Person> findAllPeople() {
		return personRepo.findAllPeople();
	}
	
	@RequestMapping(path = "/{id}", method = RequestMethod.GET)
	public List<Person> findAllPeopleById(@PathVariable int id) {
		return personRepo.findAllPeopleById(id);
	}

	@RequestMapping(path = "/{id}", method = RequestMethod.PATCH)
	public void updatePerson(@PathVariable int id) {
		personRepo.updatePerson(id);
	}

	@RequestMapping(path = "/{id}", method = RequestMethod.DELETE)
	public void deletePerson(@PathVariable int id ) {
		personRepo.deletePerson(id);
	}

}
