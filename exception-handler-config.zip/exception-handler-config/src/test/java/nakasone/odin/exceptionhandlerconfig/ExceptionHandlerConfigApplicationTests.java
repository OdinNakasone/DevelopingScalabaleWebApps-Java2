package nakasone.odin.exceptionhandlerconfig;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExceptionHandlerConfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
