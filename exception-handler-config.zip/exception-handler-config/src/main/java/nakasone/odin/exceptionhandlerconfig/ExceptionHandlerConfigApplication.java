package nakasone.odin.exceptionhandlerconfig;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExceptionHandlerConfigApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExceptionHandlerConfigApplication.class, args);
	}

}
