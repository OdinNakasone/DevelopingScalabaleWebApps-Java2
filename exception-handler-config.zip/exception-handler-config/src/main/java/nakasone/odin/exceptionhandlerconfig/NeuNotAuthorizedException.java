package nakasone.odin.exceptionhandlerconfig;

public class NeuNotAuthorizedException extends IllegalArgumentException{

	private static final long serialVersionUID = 1L;

}
