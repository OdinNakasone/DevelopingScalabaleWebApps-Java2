package nakasone.odin.fantasyWorld;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;



public class VehicleRepository {
	
	private List<Vehicle> vehicles = new ArrayList<Vehicle>();
	
	public void createVehicle(Vehicle vehicle) {
		
		try {
		
			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into table
			PreparedStatement pst = con.prepareStatement("insert into vehicle values(?, ?, ?, ?, ?, ?)");
			pst.setInt(1, vehicle.getVehicleId());
			pst.setString(2, vehicle.getVehicleBrand());
			pst.setString(3, vehicle.getVehicleType());
			pst.setString(4, vehicle.getVehicleColor());
			pst.setString(5, vehicle.getVehicleReleaseDate());
			pst.setString(6, String.valueOf(vehicle.isVehicleCanFly()));

			

			// Execute the insert command using executeUpdate()
			// to make changes in database
			pst.executeUpdate();

			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		vehicles.add(vehicle);
	}
	
	
	public List<Vehicle> findAllVehicles(){
		vehicles.clear();
		try {

			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into demo table
			String sql = "SELECT * FROM vehicle";
			PreparedStatement pst = con.prepareStatement(sql);
			ResultSet res = pst.executeQuery();

			while (res.next()) { // retrieve data
				
				boolean fly;
				int id = res.getInt(1);
				String brand = res.getString(2);
				String type = res.getString(3);
				String color = res.getString(4);
				String releaseDate = res.getString(5);
				String vehicleFly = res.getString(6);
				if(vehicleFly.equalsIgnoreCase("true")) {
					fly = true;
				}else {
					fly = false;
				}
				vehicles.add(new Vehicle(id, brand, type, color, releaseDate, fly));
				
//				System.out.println(animals.toString());

			}
			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return vehicles;
		
	}
	
	public List<Vehicle> findAllVehiclesById(int id) {
		findAllVehicles();
		List<Vehicle> result = new ArrayList<Vehicle>();
		Vehicle v = vehicles.stream().filter(vehicle -> vehicle.getVehicleId() == id).findFirst().orElse(null);
		result.add(v);
		return result;
		
	}
	
	public void updateVehicle(int id){
		
		try {

			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into demo table
			String sql = "UPDATE vehicle " + "SET vehicle_brand = ? WHERE vehicle_id = ?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, "ChangedVehicleBrand");
			pst.setInt(2, id);

			// Execute the insert command using executeUpdate()
			// to make changes in database
			pst.executeUpdate();

			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void deleteVehicle(int id) {
	

		try {

			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into demo table
			String sql = "DELETE FROM vehicle " + "WHERE vehicle_id = ?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, id);

			// Execute the insert command using executeUpdate()
			// to make changes in database
			pst.executeUpdate();

			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}


