package nakasone.odin.fantasyWorld;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ResourceRepository {

	private List<Resource> resources = new ArrayList<Resource>();

	public void createResource(Resource resource) {
		try {
			
			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into table
			PreparedStatement pst = con.prepareStatement("insert into resource values(?, ?, ?, ?, ?)");

			pst.setInt(1, resource.getResourceId());
			pst.setString(2, resource.getResourceMaterial());
			pst.setFloat(3, resource.getResourceWeight());
			pst.setString(4, String.valueOf(resource.isResourceIsRadioactive()));
			pst.setString(5, resource.getResourceUsage());

			// Execute the insert command using executeUpdate()
			// to make changes in database
			pst.executeUpdate();

			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		resources.add(resource);
	}

	public List<Resource> findAllResources() {
		resources.clear();
		try {

			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into demo table
			String sql = "SELECT * FROM resource";
			PreparedStatement pst = con.prepareStatement(sql);
			ResultSet res = pst.executeQuery();

			while (res.next()) { // retrieve data
				
				boolean isRadioactive;
				int id = res.getInt(1);
				String material = res.getString(2);
				float weight = res.getFloat(3);
				String radioactive = res.getString(4);
				String usage = res.getString(5);
				if(radioactive.equalsIgnoreCase("true")) {
					isRadioactive = true;
				}else {
					isRadioactive = false;
				}
				
				resources.add(new Resource(id, material, weight, isRadioactive, usage));
				
//				System.out.println(animals.toString());

			}
			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return resources;


	}

	public List<Resource> findAllResourcesById(int id) {
		findAllResources();
		List<Resource> result = new ArrayList<Resource>();
		Resource r = resources.stream().filter(resource -> resource.getResourceId() == id).findFirst().orElse(null);
		result.add(r);
		return result;
	}

	public void updateResource(int id) {

		try {

			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into demo table
			String sql = "UPDATE resource " + "SET resource_type = ? WHERE resource_id = ?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, "ChangedResourceName");
			pst.setInt(2, id);

			// Execute the insert command using executeUpdate()
			// to make changes in database
			pst.executeUpdate();

			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void deleteResource(int id) {

		try {

			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into demo table
			String sql = "DELETE FROM resource " + "WHERE resource_id = ?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, id);

			// Execute the insert command using executeUpdate()
			// to make changes in database
			pst.executeUpdate();

			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
