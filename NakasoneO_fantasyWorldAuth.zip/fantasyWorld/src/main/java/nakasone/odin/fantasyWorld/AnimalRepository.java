package nakasone.odin.fantasyWorld;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


public class AnimalRepository {

	private List<Animal> animals = new ArrayList<Animal>();

	public void createAnimal(Animal animal) {
//		if(animals.stream().filter(a -> a.getId() == animal.getId()).count() > 0) {
//			throw new RuntimeException("The id" + animal.getId() + " already exists");
//		}
		try {
		
			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into table
			PreparedStatement pst = con.prepareStatement("insert into animal values(?, ?, ?, ?, ?, ?)");

			pst.setInt(1, animal.getAnimalId());
			pst.setString(2, animal.getAnimalName());
			pst.setString(3, animal.getAnimalType());
			pst.setString(4, animal.getAnimalGender());
			pst.setInt(5, animal.getAnimalAppendages());
			pst.setString(6, String.valueOf(animal.isAnimalFly()));

			// Execute the insert command using executeUpdate()
			// to make changes in database
			pst.executeUpdate();

			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		animals.add(animal);
	}

	public List<Animal> findAllAnimals() {
			animals.clear();
		try {

			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into demo table
			String sql = "SELECT * FROM animal";
			PreparedStatement pst = con.prepareStatement(sql);
			ResultSet res = pst.executeQuery();

			while (res.next()) { // retrieve data
				
				boolean fly;
				int id = res.getInt(1);
				String animalName = res.getString(2);
				String animalType = res.getString(3);
				String animalGender = res.getString(4);
				int animalAppendage = res.getInt(5);
				String animalFly = res.getString(6);
				if(animalFly.equalsIgnoreCase("true")) {
					fly = true;
				}else {
					fly = false;
				}
				animals.add(new Animal(id, animalName, animalType, animalGender, animalAppendage, fly));
				
//				System.out.println(animals.toString());

			}
			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return animals;

	}

	public List<Animal> findAllAnimalsById(int id) {
		findAllAnimals();
		List<Animal> result = new ArrayList<Animal>();
		Animal an = animals.stream().filter(animal -> animal.getAnimalId() == id).findFirst().orElse(null);
		result.add(an);
		return result;
	}

	public void updateAnimal(int id) {

		try {

			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into demo table
			String sql = "UPDATE animal " + "SET animal_name = ? WHERE animal_id = ?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, "ChangedAnimalName");
			pst.setInt(2, id);

			// Execute the insert command using executeUpdate()
			// to make changes in database
			pst.executeUpdate();

			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void deleteAnimal(int id) {

		try {

			// Initialize the database
			Connection con = FantasyDatabaseConnection.initializeDatabase();

			// Create a SQL query to insert data into demo table
			String sql = "DELETE FROM animal " + "WHERE animal_id = ?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, id);

			// Execute the insert command using executeUpdate()
			// to make changes in database
			pst.executeUpdate();

			// Close all the connections
			pst.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
